#ifndef MODEL_HPP
#define MODEL_HPP

template <class T_1, class T_2>
class model {
protected:
  T_1 data;
  T_2 par;
};

#endif